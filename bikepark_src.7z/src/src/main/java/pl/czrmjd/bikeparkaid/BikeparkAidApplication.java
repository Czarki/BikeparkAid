package pl.czrmjd.bikeparkaid;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BikeparkAidApplication {

    public static void main(String[] args) {
        SpringApplication.run(BikeparkAidApplication.class, args);
    }

}
