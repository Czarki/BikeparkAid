package pl.czrmjd.bikeparkaid.remote.model;

public enum TrainingType {
    PERSONAL, GROUP
}
