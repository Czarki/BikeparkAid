package pl.czrmjd.bikeparkaid.remote.model;

public enum PassType {
    SEASON, DAILY, FIVE_TIMES
}
