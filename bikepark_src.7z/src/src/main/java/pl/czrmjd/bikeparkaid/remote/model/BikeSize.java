package pl.czrmjd.bikeparkaid.remote.model;

public enum BikeSize {
    XL, L, M, S
}
