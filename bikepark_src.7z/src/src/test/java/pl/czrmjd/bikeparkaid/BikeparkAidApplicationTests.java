package pl.czrmjd.bikeparkaid;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BikeparkAidApplicationTests {

    @Test
    void contextLoads() {
    }

}
