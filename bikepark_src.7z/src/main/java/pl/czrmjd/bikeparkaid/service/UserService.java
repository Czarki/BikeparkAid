package pl.czrmjd.bikeparkaid.service;

import lombok.AllArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import pl.czrmjd.bikeparkaid.data.model.UserEntity;
import pl.czrmjd.bikeparkaid.data.repository.UserRepository;
import pl.czrmjd.bikeparkaid.remote.model.RegistrationDto;

//klasa sluzaca do interakcji z baza danych z tabela users
@Service
public class UserService {
//    klasa sluzaca do generowania hasha i sprawdzania czy pasuje
    private final PasswordEncoder passwordEncoder;
    private final UserRepository userRepository;

    public UserService(PasswordEncoder passwordEncoder, UserRepository userRepository) {
        this.passwordEncoder = passwordEncoder;
        this.userRepository = userRepository;
    }

//    metoda do umieszczenia uzytkownika w bazie danych
    public void register(RegistrationDto registrationDto) {
        String passwordHash = passwordEncoder.encode(registrationDto.getPassword());
//        powinnismy sprawdzic czy juz nie ma usera o takim adres email
    }

//    metoda saprawdzajaca czy istnieje w bazie user o takim emailu i hasle
    public boolean checkExistUserByEmailAndPassword(String email, String password) {
        String passwordHash = passwordEncoder.encode(password);
//        TODO: do implementacji
        return true;
    }

//    pobranie usera na podstawie emaila
    public UserEntity getUserByEmail(String email) {
        //        TODO: do implementacji
        return userRepository.findByEmail(email);
    }
}
