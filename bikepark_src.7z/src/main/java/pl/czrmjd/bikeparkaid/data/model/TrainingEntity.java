package pl.czrmjd.bikeparkaid.data.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import pl.czrmjd.bikeparkaid.remote.model.TrainingType;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.Period;


//klasa reprezentujaca tabele w bazie danych, tabela nizej przechowuje informacje o uzytkownikach
//@Entity - dajemy znac bibliotece ze w tej klasie znajduje sie reprezentacja modelu tabeli
//@Table - precyzujemy nazwe tabeli
//@Column - definiujemy nazwe kolumny

@AllArgsConstructor
@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "training")
public class TrainingEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;
    @Column(name = "name")
    private String name;
    @Column (name = "type")
    private TrainingType type;
    @Column (name = "date_start")
    private LocalDateTime dateTimeStart;
    @Column (name = "date_end")
    private LocalDateTime dateTimeEnd;
    @Column (name = "duration")
    private Period duration;
    @Column (name = "price")
    private BigDecimal price;
}
