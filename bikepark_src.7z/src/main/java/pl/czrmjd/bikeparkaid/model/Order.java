package pl.czrmjd.bikeparkaid.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.time.LocalDate;

@AllArgsConstructor
@Getter
public class Order {
    private final Integer id;
    private final Integer bikeId;
    private final LocalDate bikeDateStart;
    private final LocalDate bikeDateEnd;
    private final Integer trainingId;
    private final Integer userId;
}
